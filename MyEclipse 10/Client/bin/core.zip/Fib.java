package core;

import java.math.BigInteger;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Fib extends Remote {
    public BigInteger getFib(int n) throws RemoteException;
    public BigInteger getFib(BigInteger n) throws RemoteException;
}
