package com.kms.action;

import java.util.List;

import com.kms.dao.PersonDao;
import com.kms.pojo.Person;
import com.opensymphony.xwork2.ActionSupport;
import com.opensymphony.xwork2.ModelDriven;

public class PersonFormAction extends ActionSupport implements ModelDriven<Person>{
	private static final String ADD = "add";
	private static final String DELETE = "delete";
	private static final String UPDATE = "update";
	private static final String LIST = "list";
	private PersonDao personDao = new PersonDao();
	private List<Person> list = personDao.lps();
	private  Person person = new Person();
	
	@Override
	public Person getModel() {
		if(this.getPerson() == null){
			this.setPerson(new Person());
		}
		return getPerson();
	}
	
	@Override
	public String execute() throws Exception {
		System.out.println(person.getName());
		System.out.println(person.getAge());
		System.out.println(person.getDate());
		return SUCCESS;
	}

	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}

	public String add() {
		personDao.addPerson(person);
		System.out.println("--add---------------------------------");
		return ADD;
	}

	public String delete() {
		personDao.deletePerson(person);
		System.out.println("--delete---------------------------------");
		return DELETE;
	}

	public String update() {
		personDao.updatePerson(person);
		System.out.println("--update---------------------------------");
		return UPDATE;
	}

	public String list() {
		System.out.println("--list---------------------------------");
		return LIST;
	}

	public List<Person> getList() {
		return list;
	}
}
