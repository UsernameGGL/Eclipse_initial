package com.kms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.kms.pojo.Person;

public class PersonDao extends BaseDao {
	
//	列举Person表单数据
	public List<Person> lps(){
		List<Person> lps = new ArrayList<Person>();
		String sql = "select name, age,date from person";
		Connection connection = null;
		Statement statement = null;
		ResultSet resultSet = null;
		
		try {
			connection = super.getConnection();
			statement = connection.createStatement();
			resultSet = statement.executeQuery(sql);
			while (resultSet.next()) {
				Person person = new Person();
				person.setName(resultSet.getString("name"));
				person.setAge(resultSet.getInt("age"));
				person.setDate(resultSet.getDate("date"));
				lps.add(person);
			}
			
		} catch (Exception e) {
			System.out.println("连接失败！"+e.getMessage());
			lps = null;
		} finally{
			try {
				statement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
		return lps;
	}

//	增加人员信息记录
	public int addPerson(Person p){
		int n = -1;
		String sql = "insert into person(name,pwd,age,date) "
				+" values (?,?,?,?)";
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try{
			connection = super.getConnection();
			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setObject(1, p.getName());
			preparedStatement.setObject(2, p.getPwd());
			preparedStatement.setObject(3, p.getAge());
			preparedStatement.setObject(4, p.getDate());
			
			n = preparedStatement.executeUpdate();
		}catch(Exception e){
			System.out.println("插入数据失败！"+e.getMessage());
		}finally{
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return n;
	}
	
//	修改人员信息记录
	public int updatePerson(Person p){
		int n = -1;
		String sql = "update person set pwd = ( ? ), age = ( ? ), date = ( ? ) where name = ( ? )";
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try{
			connection = super.getConnection();
			preparedStatement = connection.prepareStatement(sql);

			preparedStatement.setObject(1, p.getPwd());
			preparedStatement.setObject(2, p.getAge());
			preparedStatement.setObject(3, p.getDate());
			preparedStatement.setObject(4, p.getName());
			
			n = preparedStatement.executeUpdate();
		}catch(Exception e){
			System.out.println("修改信息失败！"+e.getMessage());
		}finally{
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return n;
	}

//	删除人员信息记录
	public int deletePerson(Person p){
		int n = -1;
		String sql = "delete from person where name = ( ? )";
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try{
			connection = super.getConnection();
			preparedStatement = connection.prepareStatement(sql);
			
			preparedStatement.setObject(1, p.getName());
			
			n = preparedStatement.executeUpdate();
		}catch(Exception e){
			System.out.println("删除信息失败！"+e.getMessage());
		}finally{
			try {
				preparedStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return n;
	}
}
